import { eq, and, desc, count, isNotNull, inArray } from 'drizzle-orm';
import { db } from '../../config/db.js';
import { rides, payments, users, drivers, cashCollections, subscriptions, subscriptionPlans, countries } from '../../../drizzle/schema/index.js';
import { publishEvent, TOPICS } from '../../config/kafka.js';
import { paginate } from '../../utils/response.js';
import { getGateway, gatewayForCurrency } from '../payment/payment.service.js';
import { formatMoney } from '../../utils/money.js';
import { withIdempotency } from '../../utils/idempotency.js';
import { postTransaction, getOrCreateSystemAccount, getOrCreateWalletAccount } from '../ledger/ledger.service.js';
import { getOrCreateWallet } from '../wallet/wallet.service.js';
import { handleDisputeEvent } from '../dispute/dispute.service.js';
import { resolveCommissionRule, computeCommission } from '../commission/commission.service.js';
import { getOrCalculateRideFinancials } from '../ride-financial/ride-financial.service.js';
import { publishNotification } from '../notification/notification-events.js';


// ── Rider — pay online ─────────────────────────────────────────────────────────

// idempotencyKey comes from the client's Idempotency-Key header (required — see
// ride-payment.routes.js) so a retried/double-submitted initiate request returns the
// original gateway order instead of creating a second one.
export async function initiateRidePayment(riderId, rideId, idempotencyKey) {
  return withIdempotency('ride_payment_initiate', idempotencyKey, riderId, async () => {
    const ride = await _loadPayableRideForUser(rideId, riderId);
    const payAmountMinor = ride.finalFareMinor;

    const gateway = gatewayForCurrency(ride.currencyCode);
    if (!gateway) {
      return _markRidePaid(ride, {
        method: 'online', gateway: 'none', gatewayPaymentId: 'dev_payment_' + Date.now(), gatewayOrderId: null,
        amountMinor: payAmountMinor, payerId: riderId,
      });
    }

    const order = await gateway.createOrder({
      amountMinor: payAmountMinor,
      currencyCode: ride.currencyCode,
      metadata: { rideId, riderId },
      idempotencyKey,
    });

    const [payment] = await db.insert(payments).values({
      rideId, subscriptionId: null,
      countryId: await _requireCountryId(ride),
      gateway: gateway.name,
      currencyCode: ride.currencyCode,
      amountMinor: payAmountMinor,
      status: 'created',
      gatewayOrderId: order.gatewayOrderId,
      metadata: { payerId: riderId },
    }).returning();

    await db.update(rides).set({ paymentMethod: 'online', paymentStatus: 'processing' }).where(eq(rides.id, rideId));

    return { ...order, paymentAttemptId: payment.id };
  });
}

export async function verifyRidePayment(riderId, rideId, orderRef, paymentRef, signature) {
  const ride = await _loadPayableRideForUser(rideId, riderId);

  const gateway = gatewayForCurrency(ride.currencyCode);
  if (!gateway) {
    return _markRidePaid(ride, {
      method: 'online', gateway: 'none', gatewayPaymentId: paymentRef, gatewayOrderId: orderRef,
      amountMinor: ride.finalFareMinor, payerId: riderId,
    });
  }

  const verified = await gateway.verifyPayment({ orderRef, paymentRef, signature });
  if (!verified) throw { statusCode: 400, message: 'Payment verification failed' };

  const [attempt] = await db.select().from(payments)
    .where(and(eq(payments.gatewayOrderId, orderRef), eq(payments.rideId, rideId))).limit(1);

  return _markRidePaid(ride, {
    method: 'online', gateway: gateway.name, gatewayPaymentId: paymentRef, gatewayOrderId: orderRef,
    paymentAttemptId: attempt?.id,
    amountMinor: attempt?.amountMinor, payerId: riderId,
  });
}

// ── Driver — record cash collection ────────────────────────────────────────────

export async function recordCashCollection(driverId, rideId, collectedAmountMinor = null) {
  const ride = await _loadPayableRide(and(eq(rides.id, rideId), eq(rides.driverId, driverId)));

  const finalCollectedMinor = collectedAmountMinor ?? ride.finalFareMinor;

  const [payment] = await db.insert(payments).values({
    rideId, subscriptionId: null,
    countryId: await _requireCountryId(ride),
    gateway: 'cash',
    currencyCode: ride.currencyCode,
    amountMinor: ride.finalFareMinor,
    status: 'captured',
    gatewayOrderId: null,
    gatewayPaymentId: null,
  }).returning();

  const updated = await _markRidePaid(ride, { method: 'cash', gateway: 'cash', paymentAttemptId: payment.id });

  // Calculate platform commission for cash auditing & settlement tracking dynamically
  let commissionMinor = 0;
  try {
    const commission = await resolveRideCommission(ride);
    commissionMinor = commission?.commissionMinor ?? Math.round(ride.finalFareMinor * 0.2);
  } catch {
    commissionMinor = Math.round(ride.finalFareMinor * 0.2);
  }

  // Insert cash collection record for admin cash management & reconciliation
  try {
    const isMismatch = finalCollectedMinor !== ride.finalFareMinor;
    await db.insert(cashCollections).values({
      rideId,
      driverId,
      expectedAmountMinor: ride.finalFareMinor,
      collectedAmountMinor: finalCollectedMinor,
      platformCommissionMinor: commissionMinor,
      currencyCode: ride.currencyCode || 'INR',
      status: isMismatch ? 'mismatch' : 'reported',
      reportedAt: new Date(),
    });
  } catch (err) {
    console.error('Failed to log cash_collections entry:', err);
  }

  // Fire after the state-changing write lands — an audit-log hiccup shouldn't leave the
  // payments row captured while the ride is still stuck showing unpaid.
  await publishEvent(TOPICS.AUDIT_LOG, {
    actorId: driverId, actorType: 'driver',
    action: 'RIDE_CASH_COLLECTED', entityType: 'ride', entityId: rideId,
  });

  return updated;
}

// ── Gateway webhook ─────────────────────────────────────────────────────────────
// Split in two so the route can verify+parse synchronously (reject bad signatures outright)
// while the actual business logic runs asynchronously via the webhook-processing job — see
// ride-payment.routes.js and jobs/webhook-processing.job.js.

// Rejects unsigned/invalid webhooks outright — never queues something we can't verify.
export function parseAndVerifyWebhook(gatewayName, rawBody, signature) {
  const gateway = getGateway(gatewayName);
  if (!gateway.isConfigured) {
    console.log(`[RidePayment] ${gatewayName} webhook received but not configured — ignoring.`);
    return null;
  }
  if (!gateway.verifyWebhookSignature(rawBody, signature)) {
    throw { statusCode: 400, message: 'Invalid webhook signature' };
  }
  const event = gateway.parseWebhookEvent(rawBody, signature);
  return event ? { ...event, gatewayName } : null;
}

export async function processWebhookEvent(event) {
  // Dispute events can land on any of the three webhook routes — dispatch by looking up the
  // disputed payment, not by which route received it. See dispute.service.js.
  if (event.kind === 'dispute') return handleDisputeEvent(event);

  const { rideId } = event.metadata || {};
  if (!rideId) return;

  const [ride] = await db.select().from(rides).where(eq(rides.id, rideId)).limit(1);
  if (ride && ride.paymentStatus !== 'paid') {
    const [attempt] = await db.select().from(payments)
      .where(and(eq(payments.gatewayOrderId, event.orderRef), eq(payments.rideId, rideId))).limit(1);
    await _markRidePaid(ride, {
      method: 'online', gateway: event.gatewayName, gatewayPaymentId: event.paymentRef, gatewayOrderId: event.orderRef,
      paymentAttemptId: attempt?.id,
    });
  }
}

// ── Reads ─────────────────────────────────────────────────────────────────────

export async function getRidePaymentStatus(rideId, requester) {
  const [ride] = await db.select().from(rides).where(eq(rides.id, rideId)).limit(1);
  if (!ride) throw { statusCode: 404, message: 'Ride not found' };

  if (requester.role === 'rider' && ride.riderId !== requester.id) throw { statusCode: 403, message: 'Not your ride' };
  if (requester.role === 'driver' && ride.driverId !== requester.id) throw { statusCode: 403, message: 'Not your ride' };

  const [payment] = await db.select().from(payments)
    .where(eq(payments.rideId, rideId)).orderBy(desc(payments.createdAt)).limit(1);

  let driverPaymentBreakdown = null;
  if (requester.role === 'driver' || requester.role === 'admin') {
    const comm = ride.fareSnapshot?.commission;
    const promoDiscountMinor = comm?.promoDiscountMinor
      || ride.fareSnapshot?.breakdown?.promo?.discountAmountMinor
      || ride.fareSnapshot?.discountAmountMinor
      || 0;
    const grossFareMinor = comm?.grossFareMinor
      || ride.fareSnapshot?.grossFareMinor
      || ride.fareSnapshot?.originalEstimatedFareMinor
      || ((ride.finalFareMinor || 0) + promoDiscountMinor);
    const platformSubsidyMinor = comm?.platformSubsidyMinor ?? promoDiscountMinor;
    const commissionMinor = comm?.commissionMinor ?? 0;
    const bookingFeeMinor = comm?.bookingFeeMinor ?? 0;
    const commissionRate = comm?.rate ?? (comm?.isSubscriber ? 0 : 0.2);
    const driverEarningsMinor = comm?.driverEarningsMinor ?? Math.max(0, grossFareMinor - commissionMinor);
    const isCash = ride.paymentMethod === 'cash';

    driverPaymentBreakdown = {
      paymentMethod: ride.paymentMethod,
      paymentStatus: ride.paymentStatus,
      currencyCode: ride.currencyCode,
      grossFareMinor,
      promoDiscountMinor,
      platformSubsidyMinor,
      bookingFeeMinor,
      commissionRate,
      commissionMinor,
      driverEarningsMinor,
      isSubscriber: comm?.isSubscriber ?? false,
      collectFromCustomerMinor: isCash ? (ride.finalFareMinor || 0) : 0,
      collectFromCustomerLabel: isCash
        ? `Collect ${formatMoney(ride.finalFareMinor || 0, ride.currencyCode)} in cash from passenger`
        : 'Paid via online / wallet (Do NOT collect cash)',
      walletCreditMinor: isCash
        ? Math.max(0, platformSubsidyMinor - commissionMinor)
        : driverEarningsMinor,
      walletDebitMinor: isCash
        ? Math.max(0, commissionMinor - platformSubsidyMinor)
        : 0,
    };
  }

  return {
    rideId: ride.id, status: ride.status,
    finalFareMinor: ride.finalFareMinor, currencyCode: ride.currencyCode,
    paymentMethod: ride.paymentMethod, paymentStatus: ride.paymentStatus,
    payment: payment || null,
    driverPaymentBreakdown: driverPaymentBreakdown || undefined,
  };
}

// Full billing document for one ride — rider/driver see their own, admin sees any.
// Only available once a ride is completed (finalFareMinor is only known at that point).
export async function getRideInvoice(rideId, requester) {
  const [ride] = await db.select().from(rides).where(eq(rides.id, rideId)).limit(1);
  if (!ride) throw { statusCode: 404, message: 'Ride not found' };

  if (requester.role === 'rider' && ride.riderId !== requester.id) throw { statusCode: 403, message: 'Not your ride' };
  if (requester.role === 'driver' && ride.driverId !== requester.id) throw { statusCode: 403, message: 'Not your ride' };
  if (ride.status !== 'completed') throw { statusCode: 409, message: 'Invoice is only available for completed rides' };

  const [rider] = await db.select({ name: users.name, phone: users.phone })
    .from(users).where(eq(users.id, ride.riderId)).limit(1);
  const [driver] = ride.driverId
    ? await db.select({ name: drivers.name, phone: drivers.phone }).from(drivers).where(eq(drivers.id, ride.driverId)).limit(1)
    : [null];
  const [payment] = await db.select().from(payments)
    .where(eq(payments.rideId, rideId)).orderBy(desc(payments.createdAt)).limit(1);

  const comm = ride.fareSnapshot?.commission;
  const promoDiscountMinor = comm?.promoDiscountMinor
    || ride.fareSnapshot?.breakdown?.promo?.discountAmountMinor
    || ride.fareSnapshot?.discountAmountMinor
    || 0;
  const grossFareMinor = comm?.grossFareMinor
    || ride.fareSnapshot?.grossFareMinor
    || ride.fareSnapshot?.originalEstimatedFareMinor
    || ((ride.finalFareMinor || 0) + promoDiscountMinor);
  const platformSubsidyMinor = comm?.platformSubsidyMinor ?? promoDiscountMinor;
  const commissionMinor = comm?.commissionMinor ?? 0;
  const bookingFeeMinor = comm?.bookingFeeMinor ?? 0;
  const commissionRate = comm?.rate ?? (comm?.isSubscriber ? 0 : 0.2);
  const driverEarningsMinor = comm?.driverEarningsMinor ?? Math.max(0, grossFareMinor - commissionMinor);
  const isCash = ride.paymentMethod === 'cash';

  const driverPaymentBreakdown = (requester.role === 'driver' || requester.role === 'admin') ? {
    grossFareMinor,
    promoDiscountMinor,
    platformSubsidyMinor,
    bookingFeeMinor,
    commissionRate,
    commissionMinor,
    driverEarningsMinor,
    isSubscriber: comm?.isSubscriber ?? false,
    ruleName: comm?.ruleName || null,
    resolutionTier: comm?.resolutionTier || null,
    collectFromCustomerMinor: isCash ? (ride.finalFareMinor || 0) : 0,
    collectFromCustomerLabel: isCash
      ? `Collect ${formatMoney(ride.finalFareMinor || 0, ride.currencyCode)} in cash from passenger`
      : 'Paid via online / wallet (Do NOT collect cash)',
    walletCreditMinor: isCash
      ? Math.max(0, platformSubsidyMinor - commissionMinor)
      : driverEarningsMinor,
    walletDebitMinor: isCash
      ? Math.max(0, commissionMinor - platformSubsidyMinor)
      : 0,
  } : undefined;

  return {
    invoiceNumber: `INV-${ride.id.slice(0, 8).toUpperCase()}`,
    ride: {
      id: ride.id, pickupAddress: ride.pickupAddress, dropAddress: ride.dropAddress,
      requestedAt: ride.requestedAt, completedAt: ride.completedAt,
      distanceKm: ride.distanceKm, durationMin: ride.durationMin,
    },
    rider: rider || null,
    driver: driver || null,
    currencyCode: ride.currencyCode,
    fareBreakdown: ride.fareSnapshot?.breakdown || {},
    estimatedFareMinor: ride.estimatedFareMinor,
    grossFareMinor,
    finalFareMinor: ride.finalFareMinor,
    commissionBreakdown: driverPaymentBreakdown,
    driverPaymentBreakdown,
    payment: {
      method: ride.paymentMethod, status: ride.paymentStatus,
      gateway: payment?.gateway ?? null, gatewayPaymentId: payment?.gatewayPaymentId ?? null,
      paidAt: payment?.status === 'captured' ? payment.updatedAt : null,
    },
  };
}

export async function getMyRidePayments(riderId, page, limit, offset) {
  const where = and(eq(rides.riderId, riderId), isNotNull(payments.rideId));
  const [{ total }] = await db.select({ total: count() }).from(payments)
    .innerJoin(rides, eq(payments.rideId, rides.id)).where(where);
  const rows = await db.select({ payment: payments, ride: rides })
    .from(payments)
    .innerJoin(rides, eq(payments.rideId, rides.id))
    .where(where)
    .orderBy(desc(payments.createdAt)).limit(limit).offset(offset);
  return { rows, pagination: paginate(page, limit, total) };
}

export async function listRidePaymentsAdmin(filters, page, limit, offset) {
  const conditions = [isNotNull(payments.rideId)];
  if (filters.rideId) conditions.push(eq(payments.rideId, filters.rideId));
  if (filters.status) conditions.push(eq(payments.status, filters.status));
  if (filters.gateway) conditions.push(eq(payments.gateway, filters.gateway));
  if (filters.countryId) conditions.push(eq(payments.countryId, filters.countryId));
  if (filters.paymentMethod) conditions.push(eq(rides.paymentMethod, filters.paymentMethod));
  if (filters.riderId) conditions.push(eq(rides.riderId, filters.riderId));
  if (filters.driverId) conditions.push(eq(rides.driverId, filters.driverId));
  const where = and(...conditions);

  const [{ total }] = await db.select({ total: count() }).from(payments)
    .innerJoin(rides, eq(payments.rideId, rides.id)).where(where);
  const rows = await db.select({ payment: payments, ride: rides })
    .from(payments)
    .innerJoin(rides, eq(payments.rideId, rides.id))
    .where(where)
    .orderBy(desc(payments.createdAt)).limit(limit).offset(offset);
  return { rows, pagination: paginate(page, limit, total) };
}


// ── Internals ───────────────────────────────────────────────────────────────────

async function _requireCountryId(ride) {
  const countryId = ride.countryId || ride.fareSnapshot?.countryId || ride.fareSnapshot?.breakdown?.countryId;
  if (countryId) return countryId;
  const [firstCountry] = await db.select({ id: countries.id }).from(countries).limit(1);
  if (firstCountry) return firstCountry.id;
  throw { statusCode: 422, message: 'Ride has no resolved country — cannot record payment' };
}

async function _loadPayableRide(ownershipCondition) {
  const [ride] = await db.select().from(rides).where(ownershipCondition).limit(1);
  if (!ride) throw { statusCode: 404, message: 'Ride not found' };
  if (ride.status !== 'completed') throw { statusCode: 409, message: 'Ride is not completed yet' };
  if (ride.paymentStatus === 'paid') throw { statusCode: 409, message: 'Ride has already been paid for' };
  return ride;
}

async function _loadPayableRideForUser(rideId, userId) {
  const [ride] = await db.select().from(rides).where(eq(rides.id, rideId)).limit(1);
  if (!ride) throw { statusCode: 404, message: 'Ride not found' };
  if (ride.riderId !== userId) throw { statusCode: 403, message: 'Only the primary rider can pay for this ride' };
  if (ride.status !== 'completed') throw { statusCode: 409, message: 'Ride is not completed yet' };
  if (ride.paymentStatus === 'paid') throw { statusCode: 409, message: 'Ride has already been paid for' };
  return ride;
}

// Resolves the dynamic commission rule for this ride and the driver's subscription status *at
// settlement time* (not at request time — a driver's subscription can lapse mid-ride), and
// stamps the breakdown onto ride.fareSnapshot so getRideInvoice/getRidePaymentStatus can show
// it without a schema change to `rides`. Returns null (no commission applied) if there's no
// driver to charge one against.
export async function resolveRideCommission(ride, { skipDbUpdate = false, tx = null } = {}) {
  if (!ride.driverId) return null;
  const financials = await getOrCalculateRideFinancials(ride.id, { tx });
  const breakdown = financials.breakdown || financials;

  if (!skipDbUpdate) {
    try {
      const dbClient = tx || db;
      await dbClient.update(rides).set({
        fareSnapshot: {
          ...(ride.fareSnapshot || {}),
          grossFareMinor: financials.grossFareMinor,
          commission: {
            ruleId: financials.commissionRuleId || null,
            ...breakdown,
          },
        },
      }).where(eq(rides.id, ride.id));
    } catch (err) {
      console.error('[RidePayment] Failed to update ride fareSnapshot commission:', err.message);
    }
  }

  return breakdown;
}

// Online fares: Dr the gateway's processor-clearing account, Cr the driver's wallet for their
// post-commission earnings, Cr platform_commission_revenue for the booking fee + rate cut,
// Dr platform_marketing_subsidy for promo discounts absorbed by platform.
// Cash fares: records cash memo + net settlement between platform commission and promo subsidy.
async function _postRideFareLedger(ride, paymentInfo) {
  const currencyCode = ride.currencyCode;
  let commission = null;
  try {
    commission = await resolveRideCommission(ride);
  } catch (e) {
    console.warn('[RidePayment] resolveRideCommission failed in _postRideFareLedger:', e.message);
  }

  const grossFareMinor = commission?.grossFareMinor || ride.grossFareMinor || (ride.finalFareMinor || 0);
  const promoDiscountMinor = commission?.promoDiscountMinor || 0;
  const platformSubsidyMinor = commission?.platformSubsidyMinor || promoDiscountMinor;
  const driverEarningsMinor = commission?.driverEarningsMinor ?? Math.round(grossFareMinor * 0.8);
  const commissionMinor = commission?.commissionMinor ?? (grossFareMinor - driverEarningsMinor);

  if (paymentInfo.method === 'online') {
    if (!ride.driverId) return;
    const driverWallet = await getOrCreateWallet('driver', ride.driverId);
    const [driverWalletAccount, commissionAccount, clearingAccount, subsidyAccount] = await Promise.all([
      getOrCreateWalletAccount(driverWallet.id, currencyCode, { ownerType: 'driver', ownerId: ride.driverId }),
      getOrCreateSystemAccount('platform_commission_revenue', currencyCode),
      getOrCreateSystemAccount(`processor_clearing:${paymentInfo.gateway}`, currencyCode),
      platformSubsidyMinor > 0 ? getOrCreateSystemAccount('platform_marketing_subsidy', currencyCode, { accountCategory: 'EXPENSE' }) : null,
    ]);

    const entries = [
      { accountId: clearingAccount.id, direction: 'debit', amountMinor: ride.finalFareMinor, currencyCode },
    ];

    if (platformSubsidyMinor > 0 && subsidyAccount) {
      entries.push({
        accountId: subsidyAccount.id, direction: 'debit', amountMinor: platformSubsidyMinor, currencyCode,
        description: `Marketing subsidy for promo on ride ${ride.id}`,
      });
    }

    entries.push({
      accountId: driverWalletAccount.id, direction: 'credit', amountMinor: driverEarningsMinor, currencyCode,
      reason: 'ride_fare_online', description: `Fare for ride ${ride.id}`,
      allowNegative: true,
    });

    if (commissionMinor > 0) {
      entries.push({ accountId: commissionAccount.id, direction: 'credit', amountMinor: commissionMinor, currencyCode });
    }

    await postTransaction({
      businessType: 'ride_fare_online',
      idempotencyKey: `ride_fare_online:${ride.id}`,
      referenceType: 'ride',
      referenceId: ride.id,
      entries,
    });
  } else if (paymentInfo.method === 'wallet') {
    if (!ride.driverId) return;
    const driverWallet = await getOrCreateWallet('driver', ride.driverId);
    const [driverWalletAccount, commissionAccount, clearingAccount, subsidyAccount] = await Promise.all([
      getOrCreateWalletAccount(driverWallet.id, currencyCode, { ownerType: 'driver', ownerId: ride.driverId }),
      getOrCreateSystemAccount('platform_commission_revenue', currencyCode),
      getOrCreateSystemAccount('processor_clearing:wallet', currencyCode),
      platformSubsidyMinor > 0 ? getOrCreateSystemAccount('platform_marketing_subsidy', currencyCode, { accountCategory: 'EXPENSE' }) : null,
    ]);

    const entries = [
      { accountId: clearingAccount.id, direction: 'debit', amountMinor: ride.finalFareMinor, currencyCode },
    ];

    if (platformSubsidyMinor > 0 && subsidyAccount) {
      entries.push({
        accountId: subsidyAccount.id, direction: 'debit', amountMinor: platformSubsidyMinor, currencyCode,
        description: `Marketing subsidy for promo on wallet ride ${ride.id}`,
      });
    }

    entries.push({
      accountId: driverWalletAccount.id, direction: 'credit', amountMinor: driverEarningsMinor, currencyCode,
      reason: 'ride_fare_wallet', description: `Fare earnings for ride ${ride.id}`,
      allowNegative: true,
    });

    if (commissionMinor > 0) {
      entries.push({ accountId: commissionAccount.id, direction: 'credit', amountMinor: commissionMinor, currencyCode });
    }

    await postTransaction({
      businessType: 'ride_fare_wallet',
      idempotencyKey: `ride_fare_wallet:${ride.id}`,
      referenceType: 'ride',
      referenceId: ride.id,
      entries,
    });
  } else if (paymentInfo.method === 'cash') {
    const [cashMemo, revenueMemo] = await Promise.all([
      getOrCreateSystemAccount('cash_collected_memo', currencyCode),
      getOrCreateSystemAccount('driver_fare_revenue_memo', currencyCode),
    ]);
    await postTransaction({
      businessType: 'ride_fare_cash',
      idempotencyKey: `ride_fare_cash:${ride.id}`,
      referenceType: 'ride',
      referenceId: ride.id,
      entries: [
        { accountId: cashMemo.id, direction: 'debit', amountMinor: ride.finalFareMinor, currencyCode },
        { accountId: revenueMemo.id, direction: 'credit', amountMinor: ride.finalFareMinor, currencyCode },
      ],
    });

    if (ride.driverId) {
      const netDueToPlatformMinor = commissionMinor - platformSubsidyMinor;

      if (netDueToPlatformMinor > 0) {
        // Driver owes platform net commission (commission cut minus promo subsidy offset)
        const driverWallet = await getOrCreateWallet('driver', ride.driverId);
        const [driverWalletAccount, commissionAccount] = await Promise.all([
          getOrCreateWalletAccount(driverWallet.id, currencyCode),
          getOrCreateSystemAccount('platform_commission_revenue', currencyCode),
        ]);
        await postTransaction({
          businessType: 'ride_commission_cash',
          idempotencyKey: `ride_commission_cash:${ride.id}`,
          referenceType: 'ride',
          referenceId: ride.id,
          entries: [
            {
              accountId: driverWalletAccount.id, direction: 'debit', amountMinor: netDueToPlatformMinor, currencyCode,
              reason: 'ride_commission_cash', description: `Net commission owed for cash ride ${ride.id}`, allowNegative: true,
            },
            { accountId: commissionAccount.id, direction: 'credit', amountMinor: netDueToPlatformMinor, currencyCode },
          ],
        });
      } else if (netDueToPlatformMinor < 0) {
        // Platform owes driver promo subsidy (e.g. subscribed driver where platform subsidy > commission)
        const subsidyPayoutMinor = Math.abs(netDueToPlatformMinor);
        const driverWallet = await getOrCreateWallet('driver', ride.driverId);
        const [driverWalletAccount, subsidyAccount] = await Promise.all([
          getOrCreateWalletAccount(driverWallet.id, currencyCode),
          getOrCreateSystemAccount('platform_marketing_subsidy', currencyCode, { accountCategory: 'EXPENSE' }),
        ]);
        await postTransaction({
          businessType: 'ride_subsidy_cash',
          idempotencyKey: `ride_subsidy_cash:${ride.id}`,
          referenceType: 'ride',
          referenceId: ride.id,
          entries: [
            { accountId: subsidyAccount.id, direction: 'debit', amountMinor: subsidyPayoutMinor, currencyCode, description: `Promo subsidy compensation for cash ride ${ride.id}` },
            {
              accountId: driverWalletAccount.id, direction: 'credit', amountMinor: subsidyPayoutMinor, currencyCode,
              reason: 'ride_subsidy_cash', description: `Promo subsidy payout for cash ride ${ride.id}`, allowNegative: true,
            },
          ],
        });
      }
    }
  }
}

export async function payRideWithWallet(riderId, rideId, idempotencyKey) {
  return withIdempotency('ride_fare_wallet', idempotencyKey, riderId, async () => {
    const ride = await _loadPayableRideForUser(rideId, riderId);
    const payAmountMinor = ride.finalFareMinor;

    const wallet = await getOrCreateWallet('rider', riderId);
    if (wallet.balanceMinor < payAmountMinor) {
      throw { statusCode: 422, message: `Insufficient wallet balance (${wallet.balanceMinor} < ${payAmountMinor})` };
    }

    const currencyCode = ride.currencyCode;
    const [walletAccount, clearingAccount] = await Promise.all([
      getOrCreateWalletAccount(wallet.id, currencyCode),
      getOrCreateSystemAccount('processor_clearing:wallet', currencyCode),
    ]);

    await postTransaction({
      businessType: 'ride_fare_wallet',
      idempotencyKey: `ride_fare_wallet_rider:${rideId}:${riderId}`,
      referenceType: 'ride',
      referenceId: rideId,
      entries: [
        {
          accountId: walletAccount.id, direction: 'debit', amountMinor: payAmountMinor, currencyCode,
          reason: 'ride_fare_wallet', description: `Wallet payment for ride ${rideId}`,
        },
        { accountId: clearingAccount.id, direction: 'credit', amountMinor: payAmountMinor, currencyCode },
      ],
    });

    const gatewayPaymentId = `wallet_pay_${rideId}_${riderId}`;
    return _markRidePaid(ride, {
      method: 'wallet', gateway: 'wallet', gatewayPaymentId,
      amountMinor: payAmountMinor, payerId: riderId,
    });
  });
}

async function _markRidePaid(ride, paymentInfo) {
  const payerId = paymentInfo.payerId;
  const payAmountMinor = paymentInfo.amountMinor;

  if (paymentInfo.paymentAttemptId) {
    await db.update(payments)
      .set({ status: 'captured', gatewayPaymentId: paymentInfo.gatewayPaymentId, updatedAt: new Date() })
      .where(eq(payments.id, paymentInfo.paymentAttemptId));
  } else {
    const [existing] = await db.select().from(payments)
      .where(and(eq(payments.rideId, ride.id), eq(payments.gatewayPaymentId, paymentInfo.gatewayPaymentId))).limit(1);
    if (!existing) {
      await db.insert(payments).values({
        rideId: ride.id, subscriptionId: null,
        countryId: await _requireCountryId(ride),
        gateway: paymentInfo.gateway,
        currencyCode: ride.currencyCode,
        amountMinor: payAmountMinor || ride.finalFareMinor,
        status: 'captured',
        gatewayOrderId: paymentInfo.gatewayOrderId,
        gatewayPaymentId: paymentInfo.gatewayPaymentId,
        metadata: payerId ? { payerId } : null,
      });
    }
  }

  const allCaptured = await db.select({ amountMinor: payments.amountMinor })
    .from(payments)
    .where(and(eq(payments.rideId, ride.id), eq(payments.status, 'captured')));

  const totalCaptured = allCaptured.reduce((sum, p) => sum + p.amountMinor, 0);

  if (totalCaptured >= ride.finalFareMinor) {
    await _postRideFareLedger(ride, paymentInfo);

    const [updated] = await db.update(rides)
      .set({ paymentMethod: paymentInfo.method, paymentStatus: 'paid' })
      .where(eq(rides.id, ride.id)).returning();

    await publishEvent(TOPICS.PAYMENT_SUCCESS, {
      id: ride.id, rideId: ride.id, riderId: ride.riderId, driverId: ride.driverId,
      amountMinor: ride.finalFareMinor, currencyCode: ride.currencyCode, method: paymentInfo.method,
    });

    const amountLabel = formatMoney(ride.finalFareMinor, ride.currencyCode);
    await publishNotification('PAYMENT_SUCCESS', {
      userId: ride.riderId, userType: 'rider', rideId: ride.id,
      variables: { amount: amountLabel, method: paymentInfo.method },
    });

    if (ride.driverId) {
      await publishNotification('PAYMENT_SUCCESS', {
        userId: ride.driverId, userType: 'driver', rideId: ride.id,
        variables: { amount: amountLabel, method: paymentInfo.method },
      });
    }


    return updated;
  } else {
    const [updated] = await db.update(rides)
      .set({ paymentStatus: 'processing' })
      .where(eq(rides.id, ride.id)).returning();
    return { ...updated, partial: true, totalCaptured, finalFareMinor: ride.finalFareMinor };
  }
}
