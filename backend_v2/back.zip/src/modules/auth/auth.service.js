import { eq, and, or, like, sql } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import { db } from '../../config/db.js';
import { users, drivers, admins, driverDevices, countries } from '../../../drizzle/schema/index.js';
import { redis, REDIS_KEYS } from '../../config/redis.js';
import {
  generateOtp, storeOtp, verifyOtp,
  sendOtpSms, assertCanSendOtp, markOtpSent
} from '../../utils/otp.js';
import { sendEmailVerification, verifyEmailCode } from '../../utils/emailOtp.js';
import { env } from '../../config/env.js';

const PHONE_REGEX = /^\+[1-9]\d{6,14}$/;   // E.164
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function normalizePhone(phone) {
  if (!phone) return '';
  const cleaned = phone.replace(/[\s\-()]/g, '');
  return cleaned;
}

export async function findDriverByPhone(phone) {
  if (!phone) return null;
  const raw = normalizePhone(phone);
  const digitsOnly = raw.replace(/\D/g, '');
  const last10 = digitsOnly.slice(-10);

  console.log(`[DriverAuth:findDriverByPhone] input="${phone}", raw="${raw}", digitsOnly="${digitsOnly}", last10="${last10}"`);

  // Exact match first
  let [driver] = await db.select().from(drivers).where(eq(drivers.phone, raw)).limit(1);
  if (driver) {
    console.log(`[DriverAuth:findDriverByPhone] exact match found! driverId="${driver.id}", name="${driver.name}", phone="${driver.phone}"`);
    return driver;
  }

  // Suffix match on last 10 digits
  if (last10.length >= 7) {
    const candidates = await db.select().from(drivers)
      .where(or(
        like(drivers.phone, `%${last10}`),
        eq(drivers.phone, digitsOnly),
        eq(drivers.phone, `+91${last10}`)
      )).limit(5);

    console.log(`[DriverAuth:findDriverByPhone] candidates matching last10="${last10}":`, candidates.map(c => ({ id: c.id, name: c.name, phone: c.phone })));

    for (const c of candidates) {
      const cDigits = (c.phone || '').replace(/\D/g, '');
      if (cDigits.endsWith(last10) || digitsOnly.endsWith(cDigits.slice(-10))) {
        console.log(`[DriverAuth:findDriverByPhone] suffix match selected! driverId="${c.id}", name="${c.name}", phone="${c.phone}"`);
        return c;
      }
    }
  }

  console.log(`[DriverAuth:findDriverByPhone] NO driver found matching phone="${phone}".`);
  return null;
}

function assertValidPhone(phone) {
  const norm = normalizePhone(phone);
  if (!PHONE_REGEX.test(norm) && !/^\d{10,15}$/.test(norm)) {
    throw { statusCode: 400, code: 'PHONE_INVALID', message: 'Enter a valid phone number in international format, e.g. +919876543210' };
  }
}

/**
 * Validates that a driver's phone number matches their registered country.
 * Prevents Canadian drivers from registering with Indian numbers (+91),
 * and Indian drivers from registering with Canadian/US numbers (+1).
 */
export async function validateDriverPhoneCountryMatch(phone, countryCodeOrId) {
  if (!phone || !countryCodeOrId) return;

  const normPhone = normalizePhone(phone);

  const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(countryCodeOrId);
  const condition = isUuid
    ? eq(countries.id, countryCodeOrId)
    : eq(countries.isoCode, String(countryCodeOrId).toUpperCase());

  const [country] = await db.select().from(countries).where(condition).limit(1);

  if (!country) return;

  const targetIso = country.isoCode.toUpperCase();
  const dialDigits = country.dialCode.replace(/\D/g, '');
  const digitsOnly = normPhone.replace(/\D/g, '');

  const isDialMatch = normPhone.startsWith(`+${dialDigits}`) ||
    (targetIso === 'IN' && digitsOnly.length === 10) ||
    (targetIso === 'IN' && digitsOnly.length === 12 && digitsOnly.startsWith('91')) ||
    (targetIso === 'CA' && digitsOnly.length === 11 && digitsOnly.startsWith('1'));

  if (targetIso === 'CA') {
    if (normPhone.startsWith('+91') || (digitsOnly.length === 12 && digitsOnly.startsWith('91'))) {
      throw {
        statusCode: 400,
        code: 'PHONE_COUNTRY_MISMATCH',
        message: 'Canadian drivers cannot register with an Indian phone number (+91)',
      };
    }
  }

  if (targetIso === 'IN') {
    if (normPhone.startsWith('+1') || (digitsOnly.length === 11 && digitsOnly.startsWith('1'))) {
      throw {
        statusCode: 400,
        code: 'PHONE_COUNTRY_MISMATCH',
        message: 'Indian drivers cannot register with a Canadian phone number (+1)',
      };
    }
  }

  if (!isDialMatch) {
    throw {
      statusCode: 400,
      code: 'PHONE_COUNTRY_MISMATCH',
      message: `Drivers in ${country.name} must register with a valid ${country.name} phone number (${country.dialCode})`,
    };
  }
}

function assertValidEmail(email) {
  if (!EMAIL_REGEX.test(email)) throw { statusCode: 400, code: 'EMAIL_INVALID', message: 'Enter a valid email address' };
}

// ── Rider OTP (unchanged) ──────────────────────────────────────────────────────

export async function sendOtp(phone, role = 'rider') {
  assertValidPhone(phone);
  await assertCanSendOtp(phone);

  const otp = generateOtp();
  await storeOtp(phone, otp);
  await sendOtpSms(phone, otp);
  await markOtpSent(phone);
  return { sent: true };
}

export async function verifyRiderOtp(phone, otp, app) {
  const valid = await verifyOtp(phone, otp);
  if (!valid) throw { statusCode: 400, message: 'Invalid or expired OTP' };

  let [user] = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
  const isNew = !user;

  if (!user) {
    [user] = await db.insert(users).values({ phone, isVerified: true }).returning();
  } else {
    await db.update(users).set({ isVerified: true }).where(eq(users.id, user.id));
  }

  const accessToken = app.jwt.sign({ id: user.id, role: 'rider', phone });
  const refreshToken = app.jwt.sign(
    { id: user.id, role: 'rider' },
    { secret: env.JWT_REFRESH_SECRET, expiresIn: env.JWT_REFRESH_EXPIRES_IN },
  );
  await redis.setex(REDIS_KEYS.refreshToken(user.id), 30 * 86400, refreshToken);

  return { accessToken, refreshToken, isNew, user };
}

// ── Driver mobile auth (device-scoped) ─────────────────────────────────────────

export async function driverMobileStart(phone, deviceId, countryCodeOrId = null) {
  assertValidPhone(phone);
  if (!deviceId) throw { statusCode: 400, message: 'deviceId is required' };

  if (countryCodeOrId) {
    await validateDriverPhoneCountryMatch(phone, countryCodeOrId);
  }

  await assertCanSendOtp(phone);

  console.log(`[DriverAuth:driverMobileStart] phone="${phone}", deviceId="${deviceId}", country="${countryCodeOrId || 'unspecified'}"`);
  const existing = await findDriverByPhone(phone);
  console.log(`[DriverAuth:driverMobileStart] existing driver found:`, existing ? `id=${existing.id}, name=${existing.name}, status=${existing.registrationStatus}` : 'NONE');

  const otp = generateOtp();
  await storeOtp(phone, otp);
  await sendOtpSms(phone, otp);
  await markOtpSent(phone);

  return { sent: true, isNewAccount: !existing, resendAfterSeconds: 30 };
}

export async function driverMobileResend(phone) {
  assertValidPhone(phone);
  await assertCanSendOtp(phone);

  const otp = generateOtp();
  await storeOtp(phone, otp);
  await sendOtpSms(phone, otp);
  await markOtpSent(phone);

  return { sent: true, resendAfterSeconds: 30 };
}

async function upsertDevice(driverId, deviceId, platform, fcmToken, ip) {
  const [existing] = await db.select().from(driverDevices)
    .where(and(eq(driverDevices.driverId, driverId), eq(driverDevices.deviceId, deviceId))).limit(1);

  if (existing) {
    await db.update(driverDevices).set({
      platform, fcmToken, ip, lastLoginAt: new Date(), isRevoked: false,
    }).where(eq(driverDevices.id, existing.id));
  } else {
    await db.insert(driverDevices).values({ driverId, deviceId, platform, fcmToken, ip });
  }
}

async function issueDriverTokens(driver, deviceId, app) {
  const accessToken = app.jwt.sign({ id: driver.id, role: 'driver', phone: driver.phone });
  const refreshToken = app.jwt.sign(
    { id: driver.id, role: 'driver', deviceId },
    { secret: env.JWT_REFRESH_SECRET, expiresIn: env.JWT_REFRESH_EXPIRES_IN },
  );
  await redis.setex(REDIS_KEYS.refreshToken(driver.id, deviceId), 30 * 86400, refreshToken);
  return { accessToken, refreshToken };
}

export async function driverMobileVerify(phone, otp, deviceId, platform, fcmToken, ip, app) {
  if (!deviceId) throw { statusCode: 400, message: 'deviceId is required' };
  const valid = await verifyOtp(phone, otp);
  if (!valid) throw { statusCode: 400, code: 'OTP_INVALID', message: 'Invalid or expired OTP' };

  console.log(`[DriverAuth:driverMobileVerify] phone="${phone}", otp="${otp}", deviceId="${deviceId}"`);
  let driver = await findDriverByPhone(phone);
  const isNew = !driver;

  if (!driver) {
    console.log(`[DriverAuth:driverMobileVerify] No existing driver. Creating new driver for phone="${phone}"...`);
    [driver] = await db.insert(drivers).values({
      phone: normalizePhone(phone), registrationStatus: 'mobile_verified', registrationStep: 1,
    }).returning();
    console.log(`[DriverAuth:driverMobileVerify] Created new driver id="${driver.id}".`);
  } else if (driver.registrationStatus === 'new') {
    console.log(`[DriverAuth:driverMobileVerify] Existing driver with status "new". Updating to mobile_verified...`);
    [driver] = await db.update(drivers).set({
      registrationStatus: 'mobile_verified', registrationStep: Math.max(driver.registrationStep, 1),
    }).where(eq(drivers.id, driver.id)).returning();
  } else {
    console.log(`[DriverAuth:driverMobileVerify] Found existing driver id="${driver.id}", name="${driver.name}", status="${driver.registrationStatus}", step=${driver.registrationStep}`);
  }

  if (driver.isBlocked) throw { statusCode: 403, code: 'ACCOUNT_SUSPENDED', message: 'This account is suspended' };

  await upsertDevice(driver.id, deviceId, platform, fcmToken, ip);
  const tokens = await issueDriverTokens(driver, deviceId, app);

  return {
    ...tokens, isNew, driver,
    registrationStatus: driver.registrationStatus,
    registrationStep: driver.registrationStep,
  };
}

// ── Driver email auth ───────────────────────────────────────────────────────────

export async function driverEmailStart(email) {
  assertValidEmail(email);
  return sendEmailVerification(email);
}

export async function driverEmailVerify(email, code, deviceId, platform, fcmToken, ip, app) {
  if (!deviceId) throw { statusCode: 400, message: 'deviceId is required' };
  const valid = await verifyEmailCode(email, code);
  if (!valid) throw { statusCode: 400, code: 'OTP_INVALID', message: 'Invalid or expired code' };

  let [driver] = await db.select().from(drivers).where(eq(drivers.email, email)).limit(1);
  const isNew = !driver;

  if (!driver) {
    [driver] = await db.insert(drivers).values({
      email,
      registrationStatus: 'email_verified', registrationStep: 1,
    }).returning();
  } else if (driver.registrationStatus === 'new') {
    [driver] = await db.update(drivers).set({
      registrationStatus: 'email_verified', registrationStep: Math.max(driver.registrationStep, 1),
    }).where(eq(drivers.id, driver.id)).returning();
  }

  if (driver.isBlocked) throw { statusCode: 403, code: 'ACCOUNT_SUSPENDED', message: 'This account is suspended' };

  await upsertDevice(driver.id, deviceId, platform, fcmToken, ip);
  const tokens = await issueDriverTokens(driver, deviceId, app);

  return {
    ...tokens, isNew, driver,
    registrationStatus: driver.registrationStatus,
    registrationStep: driver.registrationStep,
  };
}

// ── Legacy driver OTP (kept for backward compatibility with existing clients) ──

export async function verifyDriverOtp(phone, otp, app) {
  const valid = await verifyOtp(phone, otp);
  if (!valid) throw { statusCode: 400, message: 'Invalid or expired OTP' };

  console.log(`[DriverAuth:verifyDriverOtp] verifying OTP for phone="${phone}"...`);
  let driver = await findDriverByPhone(phone);
  const isNew = !driver;

  if (!driver) {
    console.log(`[DriverAuth:verifyDriverOtp] No existing driver found for phone="${phone}". Creating NEW blank driver row...`);
    [driver] = await db.insert(drivers).values({
      phone: normalizePhone(phone),
      registrationStatus: 'mobile_verified',
      registrationStep: 1,
    }).returning();
    console.log(`[DriverAuth:verifyDriverOtp] Inserted new driver id="${driver.id}", phone="${driver.phone}".`);
  } else {
    console.log(`[DriverAuth:verifyDriverOtp] Found existing driver id="${driver.id}", name="${driver.name}", phone="${driver.phone}". No new row created.`);
  }

  const accessToken = app.jwt.sign({ id: driver.id, role: 'driver', phone: driver.phone });
  const refreshToken = app.jwt.sign(
    { id: driver.id, role: 'driver' },
    { secret: env.JWT_REFRESH_SECRET, expiresIn: env.JWT_REFRESH_EXPIRES_IN },
  );
  await redis.setex(REDIS_KEYS.refreshToken(driver.id), 30 * 86400, refreshToken);

  return { accessToken, refreshToken, isNew, driver };
}

// ── Device management ───────────────────────────────────────────────────────────

export async function listDriverDevices(driverId) {
  return db.select().from(driverDevices)
    .where(and(eq(driverDevices.driverId, driverId), eq(driverDevices.isRevoked, false)));
}

export async function revokeDriverDevice(driverId, deviceId) {
  await db.update(driverDevices).set({ isRevoked: true })
    .where(and(eq(driverDevices.driverId, driverId), eq(driverDevices.deviceId, deviceId)));
  await redis.del(REDIS_KEYS.refreshToken(driverId, deviceId));
  return { revoked: true };
}

// ── Token management ──────────────────────────────────────────────────────────

export async function refreshTokens(token, app) {
  let payload;
  try {
    payload = app.jwt.verify(token, { secret: env.JWT_REFRESH_SECRET });
  } catch {
    throw { statusCode: 401, message: 'Invalid refresh token' };
  }
  const deviceId = payload.deviceId; // undefined for rider tokens — falls back to 'default' key
  const stored = await redis.get(REDIS_KEYS.refreshToken(payload.id, deviceId));
  if (!stored || stored !== token) throw { statusCode: 401, message: 'Refresh token revoked' };

  const accessToken = app.jwt.sign({ id: payload.id, role: payload.role });
  return { accessToken };
}

export async function logout(userId, deviceId) {
  await redis.del(REDIS_KEYS.refreshToken(userId, deviceId));
}

// ── Admin auth (bcrypt) ───────────────────────────────────────────────────────

export async function adminLogin(email, password, app) {
  const [admin] = await db.select().from(admins).where(eq(admins.email, email)).limit(1);
  if (!admin) throw { statusCode: 401, message: 'Invalid credentials' };

  const valid = await bcrypt.compare(password, admin.password);
  if (!valid) throw { statusCode: 401, message: 'Invalid credentials' };
  if (!admin.isActive) throw { statusCode: 403, message: 'Account disabled' };

  await db.update(admins).set({ lastLoginAt: new Date() }).where(eq(admins.id, admin.id));

  const accessToken = app.jwt.sign({ id: admin.id, role: admin.role, email: admin.email });
  return {
    accessToken,
    admin: { id: admin.id, name: admin.name, email: admin.email, role: admin.role },
  };
}
